//Vertex.java
//Descoteaux, Marc-Andre

public class Vertex{
	
	public int num; //vertex number
	public int items; //items at vertex
	public Vertex next; //pointer
	
	public Vertex(int v){
		num = v;
		items = 0;
		next = null;
	}
	
	public Vertex(int v, int i){
		num = v;
		items = i;
		next = null;
	}
	
	public Vertex(int v, int i, Vertex p){
		num = v;
		items = i;
		next = p;
	}
	
	
}