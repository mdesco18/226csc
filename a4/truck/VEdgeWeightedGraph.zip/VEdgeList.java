//VEdgeList.java
//Descoteaux, Marc-Andre

import java.util.*;

public class VEdgeList{
	
	public int n;
	public VEdge start;
	public VEdge rear;
	
	public VEdgeList(){
		n= 0;
		start= null;
		rear= null;
	}
	public VEdgeList(int n, VEdge start, VEdge rear){
		this.n= n;
		this.start= start;
		this.rear= rear;
	}
	
	/**
	* Returns true if this queue is empty.
	*
	* @return {@code true} if this queue is empty; {@code false} otherwise
	*/
    public boolean isEmpty() {
        return start == null;
    }
/**
     * Returns the number of items in this queue.
     *
     */
    public int size() {
        return n;
    }

/** 
	*
	* insert a new VEdge into a linked list keeping weights sorted
	*
*/
	public void insertList(int u, i, int v, j, double w){
		VEdge current;
		VEdge previous;
		current= start;
		previous= start;
		
//check if list is empty
		if(current == null){
			current = new VEdge(u, i, v, j, w, rear);
		   start = current;
		   rear = current;
//check if insertion will be at beginning of list
		}else if(start.weight > w){
		
		   current = new VEdge(u, v, w, start);
		   start = current;
		   
		}else{
//iterate through list to place insertion
			while (current.weight < w && current != rear){
				previous = current;
			   current= current.next;
			}
//check if insertion is to be appended
			if(current == rear){
				VEdge end = new VEdge(u, v, w);
				current.next = end;
				rear = end;
//insert new w
			}else{
				 
				current= new VEdge(u, v, w,current);
				previous.next = current;
			}
		}
		n++;
	}
	public void insertList(VEdge e){
		VEdge current;
		VEdge previous;
		current= start;
		previous= start;
		
//check if list is empty
		if(current == null){
		   start = e;
		   rear = e;
//check if insertion will be at beginning of list
		}else if(start.weight > e.weight){
		
		  e.next = start;
		   start = e;
		   
		   
		}else{
//iterate through list to place insertion
			while (current.weight < e.weight && current != rear){
				previous = current;
			   current= current.next;
			}
//check if insertion is to be appended
			if(current == rear){
				current.next = e;
				rear = e;
//insert new w
			}else{
				 
				e.next = current;
				previous.next = e;
			}
		}
		n++;
	}

/**
	*
	* adds a VEdge to the rear of the LinkedList
	*
*/
	public void addRear(int u, int i, int v, int j, double w){
		VEdge curr;
		curr = new VEdge(u, i, v, j, w);
		if(start == null){
			start = curr;
			rear = curr;
		}else{
			rear.next = curr;
			rear = curr;
		}
		curr.next = null;
		n++;
	}
	
	public void addRear(VEdge e){
		
		if(start == null){
			start = e;
			rear = e;
		}else{
			rear.next = e;
			rear = e;
		}
		e.next = null;
		n++;
	}
	//Returns all directed VEdges in list
	public Iterable<VEdge> edges(){

		VEdge[] list = new VEdge[n];
		int i = 0;
		for(VEdge curr = start; curr != null; curr = curr.next){
			list[i] = curr;
			i++;
		}
		Iterable<VEdge> iterable = Arrays.asList(list);
		return iterable;
	}
}