//VEdge.java
//Descoteaux, Marc-Andre
//Edge class that uses Vertex objects instead of just int

public class VEdge{
	
	public Vertex u;
	public Vertex v;
	public double weight;
	public VEdge next; //pointer
	
	public VEdge(){
		u = null;
		v = null;
		weight = 0.0;
		next = null;
	}
	/* Parameters
	
		u: vertex number of u
		v: vertex number of v
		i: number of items on u
		j: number of items on v
		w: weight of edge
		p: pointer to another VEdge for the lists
	*/
	public VEdge(int u, int i, int v, int j, double w){
		if (u < 0) throw new IllegalArgumentException("vertex index must be a nonnegative integer");
        if (v < 0) throw new IllegalArgumentException("vertex index must be a nonnegative integer");
        if (Double.isNaN(w)) throw new IllegalArgumentException("Weight is NaN");
		this.u = new Vertex(u, i);
		this.v = new Vertex(v, j);
		weight = w;
		next = null;
	}
	
	public VEdge(int u, int i, int v, int j, double w, VEdge p){
		if (u < 0) throw new IllegalArgumentException("vertex index must be a nonnegative integer");
        if (v < 0) throw new IllegalArgumentException("vertex index must be a nonnegative integer");
        if (Double.isNaN(w)) throw new IllegalArgumentException("Weight is NaN");
		this.u = new Vertex(u, i);
		this.v = new Vertex(v, j);
		weight = w;
		next = p;
	}
	
	//returns the endpoint of the given vertex
	public int other(Vertex vertex) {
        if      (vertex == u) return v;
        else if (vertex == v) return u;
        else throw new IllegalArgumentException("Illegal endpoint");
    }
	
	//compare two VEdges weights
	@Override
    public int compareTo(VEdge that) {
        return Double.compare(this.weight, that.weight);
    }
	
	public String toString(){
        return String.format("%d-%d %.5f", u.num, v.num, weight);
    }
	
}