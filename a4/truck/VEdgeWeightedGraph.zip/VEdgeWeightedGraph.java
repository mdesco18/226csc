//VEdgeWeightedGraph.java
//Descoteaux, Marc-Andre

public class VEdgeWeightedGraph{
	
	public int V; //number of vertices
	public int E; //number of VEdges
	public VEdgeList[] adj; //adjacency matrix for vertices
	
	public VEdgeWeightedGraph(int V) {
        if (V < 0) throw new IllegalArgumentException("Number of vertices must be nonnegative");
        this.V = V;
        this.E = 0;
        adj = new VEdgeList[V];
        for (int v = 0; v < V; v++) {
            adj[v] = new VEdgeList();
        }
    } 
	
	private void validateVertex(int v) {
		if (v < 0 || v > V)
			throw new IllegalArgumentException("vertex " + v + " is not between 0 and " + (V));
	}
	
	public void addVEdge(VEdge e) {
        int u = e.u;
        int v = e.v;
		validateVertex(u);
		validateVertex(v);
        adj[u].add(e);
        adj[v].add(e);
        E++;
    }
	
	public int degree(int v) {
        validateVertex(v);
        return adj[v].size();
    }

	
	public Iterable<VEdge> adj(int v) {
		validateVertex(v);
        return adj[v].edges();
    }
	
	public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(V + " " + E + "\n");
        for (int v = 0; v < V; v++) {
            s.append(v + ": ");
            for (VEdge e : adj(v)) {
                s.append(e + "  ");
            }
            s.append("\n");
        }
        return s.toString();
    }

	
}